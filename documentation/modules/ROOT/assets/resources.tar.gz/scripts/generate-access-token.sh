#! /usr/bin/sh

PREFIX="${1:?}"
kubectl -n "${PREFIX}" wait --for=condition=ready "accessgrant/${PREFIX}-grant" > /dev/null 2>&1
kubectl -n "${PREFIX}" get accessgrant "${PREFIX}-grant" -o json > "/tmp/${PREFIX}-grant.json"
URL="$(jq '.status.url' < "/tmp/${PREFIX}-grant.json")"
CODE="$(jq '.status.code' < "/tmp/${PREFIX}-grant.json")"
CA=$(jq -r '.status.ca' < "/tmp/${PREFIX}-grant.json" | awk '{ print "    " $0 }')
cat << EOF
apiVersion: skupper.io/v1alpha1
kind: AccessToken
metadata:
  name: ${PREFIX}-token
spec:
  url: ${URL}
  code: ${CODE}
  ca: |
${CA}
EOF
